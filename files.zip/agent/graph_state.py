class GraphStateSchema(BaseModel):
    """Canonical Pydantic schema for GraphState validation and normalization."""
    # Core findings data
    raw_findings: Optional[List[Dict[str, Any]]] = Field(default_factory=list)
    ...