if advanced_router_node:
    wf.add_node("advanced_router", advanced_router_node)
    wf.add_edge("enrich", "advanced_router")
    wf.add_conditional_edges("advanced_router",
        lambda s: advanced_router_node(s),  # returns node name
        {
            "summarize": "summarize",
            "baseline": "plan_baseline",
            "compliance": "compliance",
            "risk": "risk",
            "human_feedback": "human_feedback",
            "error": "error_handler",
        }
    )