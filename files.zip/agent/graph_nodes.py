# After setting state['suggested_rules']
if 'suggested_rules' in state and 'rule_suggestions' not in state:
    state['rule_suggestions'] = state['suggested_rules']